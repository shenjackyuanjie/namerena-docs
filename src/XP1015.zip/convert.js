var aname = ["HP","攻","防","速","敏","魔","抗","智"]

var sname = [
	"火球", "冰冻", "雷击", "地裂", "吸血", "投毒", "连击",
	"会心", "瘟疫", "命轮", "狂暴", "魅惑", "加速", "减速",
	"诅咒", "治愈", "苏生", "净化", "铁壁", "蓄力", "聚气",
	"潜行", "血祭", "分身", "幻术", "防御", "守护", "反弹",
	"护符", "护盾", "反击", "吞噬", "亡灵", "垂死", "隐匿",
	"啧", "啧", "啧", "啧", "啧"]

function onStart() {
    var tmp1 = document.getElementById("input").value.trim()
    var names = Array.prototype.slice.call(tmp1.split('\n'));

    var output = document.getElementById("output")
    var dis = document.getElementById("dis")
    output.value=''

    var tmpsize = parseInt(document.getElementById("tmpsize").value.trim())

    var x = new Array(43)
    var y = new Array()
    var name = new Name()
    var s = 0,tmp2=0,tmp3=''
    var length = names.length
    var Loop = setInterval(function(){
        tmp3=''
        for(let ii=0;ii<tmpsize;ii++){
            s=tmp2+ii
            var nametmp = Array.prototype.slice.call(names[s].split('@'));
            if(nametmp.length<2)nametmp[1]=nametmp[0]
            name.load_team(nametmp[1])
            name.load_name(nametmp[0])

            if(nametmp[1]=="!")name.TV()

            var props = name.calc_props()
            name.calc_skills()
            for (let j = 0; j < 7; j++)props[j] += 36;
            x = new Array(43)
            y = new Array(35)

            x[0] = props[7]
            for (let i = 0; i < 7; i++) {
                x[i + 1] = props[i]
            }
            for (let i = 0; i < 35; i++) {
                var cf = 0;
                for (let k = 0; k < 16; k++) {
                    if (name.skill[k] == i) {
                        x[i + 8] = name.freq[k]
                        cf = 1;
                    }
                }
                if (cf == 0) {
                    x[i + 8] = 0
                }
            }

            tmp3 += names[s]
            for (let i = 0; i < 8; i++)tmp3+=' '+aname[i]+x[i]
            var ptr1 = 0
            for (let i = 8; i < 43; i++){
                if(x[i]>0){
                    y[ptr1]=[x[i],sname[i-8]]
                    ptr1++
                }
            }
            var ytmp
            for(let i=0;i<ptr1;i++){
                for(let j=0;j<ptr1-1;j++){
                    if(y[j][0]<y[j+1][0]){
                        ytmp=y[j]
                        y[j]=y[j+1]
                        y[j+1]=ytmp
                    }
                }
            }
            
            var sum = x[0]/3 +x[1]+x[2]+x[3]+x[4]+x[5]+x[6]+x[7]
            tmp3+=' 八围'+sum.toFixed(1)
            sum = 0
            for(let i=0;i<ptr1;i++){
                sum += y[i][0]
            }
            tmp3+=' 技能'+sum

            for(let i=0;i<ptr1;i++)tmp3+=' '+y[i][1]+y[i][0]

            tmp3 += '\n'

            names[s]=null
            s++
            if(ii==tmpsize-1 || s==length){
                dis.innerText = (s)+' / '+length
                output.value += tmp3
            }
            if(s==length){
                // window.alert("测试完成");
                dis.innerText = "测试完成"
                clearInterval(Loop)
                break
            }
        }
        tmp2+=tmpsize
    },0)
}